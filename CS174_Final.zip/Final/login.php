<?php
$hn = 'localhost';
$un = 'root';
$pw = 'root';
$db = 'AntivirusDatabase';
?>

